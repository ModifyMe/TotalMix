import os
import shutil
pkg_data_path=os.path.dirname(__file__)+'/data'