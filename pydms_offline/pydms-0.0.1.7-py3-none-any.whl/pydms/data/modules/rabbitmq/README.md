RabbitMQ
---
Producer->Exchange--(Binding)-->Queue-->Consumer