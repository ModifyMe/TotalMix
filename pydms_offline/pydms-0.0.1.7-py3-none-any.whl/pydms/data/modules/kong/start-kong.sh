docker start kong-database
docker start kong
docker start konga